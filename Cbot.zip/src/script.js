const chatBox = document.getElementById('chat-box');

const userInput = document.getElementById('user-input');

// Replace this with your actual OpenAI API key (safe only for local testing)

const OPENAI_API_KEY = "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";

async function sendMessage() {

  const message = userInput.value.trim();

  if (!message) return;

  // Display user message

  displayMessage(message, "user");

  userInput.value = "";

  // Show temporary typing indicator

  const typingDiv = displayMessage("Typing...", "bot");

  // Fetch AI response

  const botResponse = await getAIResponse(message);

  // Replace typing with actual response

  typingDiv.innerText = botResponse;

}

function displayMessage(text, sender) {

  const msgDiv = document.createElement("div");

  msgDiv.classList.add("message", sender === "user" ? "user-message" : "bot-message");

  msgDiv.innerText = text;

  chatBox.appendChild(msgDiv);

  chatBox.scrollTop = chatBox.scrollHeight; // Auto scroll

  return msgDiv;

}

async function getAIResponse(userMessage) {

  try {

    const response = await fetch("https://api.openai.com/v1/chat/completions", {

      method: "POST",

      headers: {

        "Content-Type": "application/json",

        "Authorization": `Bearer ${OPENAI_API_KEY}`

      },

      body: JSON.stringify({

        model: "gpt-4o-mini", // Small, fast GPT model

        messages: [{ role: "user", content: userMessage }],

        max_tokens: 150

      })

    });

    const data = await response.json();

    return data.choices?.[0]?.message?.content || "Sorry, I couldn't generate a response.";

  } catch (error) {

    console.error("Error:", error);

    return "Error: Unable to connect to AI.";

  }

}